#ifndef GRAYMAP_H
#define GRAYMAP_H

#include <QVector>
#include <QRgb>

extern QVector<QRgb> graymap;

#endif
