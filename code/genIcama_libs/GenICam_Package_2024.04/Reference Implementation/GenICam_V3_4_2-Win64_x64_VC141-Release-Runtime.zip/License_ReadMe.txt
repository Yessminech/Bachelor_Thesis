==============
== Licenses ==
==============

GenICam comes in two versions
~ a runtime version
  GenICam runtime and SDK files for developing and/or running GenICambased software.
~ a development version.
  GenICam complete source code for developing and building the GenICam SDK.

The runtime version comes under the following license:

  Copyright (c) EMVA and contributors (see source files)
  All rights reserved

  Redistribution and use in source and binary forms, without modification,
  are permitted provided that the following conditions are met:

  ~ Redistributions of source code must retain the above copyright notice,
    this list of conditions and the following disclaimer.

  ~ Redistributions in binary form must reproduce the above copyright notice,
    this list of conditions and the following disclaimer in the documentation
    and/or other materials provided with the distribution.

  ~ Neither the name of the GenICam standard group nor the names of its contributors
    may be used to endorse or promote products derived from this software without
    specific prior written permission.


  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY
  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
  SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
  OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.

The development version comes under the GenICam license which can be found in licenses/GenICam_License.pdf
or can be downloaded from http://www.genicam.org.

When distributing GenICam runtime libraries, this file and the license for the development version which
also describes GenICam compliancy and rules (GenICam_License.pdf) must also be distributed for the
sake of completeness of the license information.

GenICam uses the following 3rd party software packages (*):

Package     Version              License         Internet                                        Used by
====================================================================================================================
CLSerAll    1.1.0                NI              http://sourceforge.net/projects/clallserial     CLAllSerial, CLProtocol
CppUnit     1.10.2 (modified)    LGPL            http://cppunit.sourceforge.net                  GenICam unit tests
Expat       2.5.0                MIT license     https://libexpat.github.io/                     XmlParser, FirmwareUpdate
GenX        cs-1                 MIT license     http://www.tbray.org/ongoing/genx               XmlParser, FirmwareUpdate
Log4Cpp     1.0 (modified)       LGPL            http://log4cpp.sourceforge.net                  GenApi
Mathparser  0.3 (modified)       LGPL            http://kirya.narod.ru/mathparser.html           GenApi
miniz       1.14                 MIT license     https://github/richgel999/miniz                 FirmwareUpdate, GenTL
PCRE2       10.42                BSD license     http://www.pcre.org/                            FirmwareUpdate
regexp                           MIT license     https://git.codesynthesis.com/cgit/xsde/        FirmwareUpdate
xs3p        1.5.5                DSTC            http://xml.fiforms.org/xs3p/index.html          GenApi Schema documentation
XSDe                             Proprietary     NA                                              XmlParser, FirmwareUpdate
XSLTProc                         MIT license     http://xmlsoft.org/XSLT/xsltproc2.html          GenApi Schema documentation
xxhash                           New BSD         https://code.google.com/p/xxhash/               GenApi
zlib        1.3.0                Free            https://www.zlib.net/                           GenTL
(*) When distributing subset of GenICam libraries, any unused 3rd party software packages and their
license information may be omitted.

Note that the XSDe license was purchased by one of the members of the committee but
allows all members to re-compile the parser as long as only the GenApi XML vocabulary is used.
The XSDe free proprietary license is used for the firmware update module.

All license texts come as part of the GenICam distribution in the licenses
subdirectory. If not, you can download them from the Internet.

License     File                    Where to find the license texts
==================================================================================
CLSerAll    CLSerAll_LICENSE.txt    http://sourceforge.net/projects/clallserial
Expat       expat-COPYING.txt       https://github.com/libexpat/libexpat/blob/master/expat/COPYING
GenICam     GenICam_License.pdf     http://www.genicam.org
GenX        genx-LICENSE.txt        http://www.tbray.org/ongoing/genx/COPYING
LGPL        LGPL.txt                http://www.gnu.org/licenses/lgpl.html
PCRE2       pcre2_License.txt       http://www.pcre.org/licence.txt
regexp      regexp-LICENSE.txt      https://git.codesynthesis.com/cgit/xsde/xsde/tree/libxsde/xsde/c/regexp/LICENSE
xs3p        xs3p_License.mht        http://xml.fiforms.org/xs3p/index.html
XSDe        XSDe License.pdf        NA
XSDe        Free                    NA
            Proprietary
            License
XSLTProc    MIT_License.txt         http://opensource.org/licenses/mit-license.html
xxhash      xxhash_License.txt      http://opensource.org/licenses/BSD-3-Clause

Last but not least GenICam redistributes the C/C++ runtime DLLs of the
Microsoft Visual C++ compiler.

