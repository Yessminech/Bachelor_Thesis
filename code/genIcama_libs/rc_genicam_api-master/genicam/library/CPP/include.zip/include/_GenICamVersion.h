//  This file is generated automatically. Do not modify! 
#define GENICAM_VERSION_MAJOR 3 
#define GENICAM_VERSION_MINOR 4 
#define GENICAM_VERSION_SUBMINOR 0

#define GENICAM_MAIN_COMPILER 

/* #undef GENICAM_COMPANY_SUFFIX */
#define GENICAM_SVN_REVISION 6649
