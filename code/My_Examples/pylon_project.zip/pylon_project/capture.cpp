#include <pylon/PylonIncludes.h>
#include <pylon/PylonImage.h>
#include <pylon/ImagePersistence.h>

int main() {
    Pylon::PylonInitialize(); // Initialize Pylon SDK

    try {
        Pylon::CInstantCamera camera(Pylon::CTlFactory::GetInstance().CreateFirstDevice()); // Get first camera
        camera.Open(); // Open camera

        camera.StartGrabbing(1); // Grab one image
        Pylon::CGrabResultPtr grabResult;
        camera.RetrieveResult(5000, grabResult, Pylon::TimeoutHandling_ThrowException);

        if (grabResult->GrabSucceeded()) {
            std::cout << "Image captured successfully!" << std::endl;

            // Convert the image and save it
            Pylon::CPylonImage image;
            image.AttachGrabResultBuffer(grabResult);

            std::string filename = "captured_image.png";
            Pylon::CImagePersistence::Save(Pylon::ImageFileFormat_Png, filename.c_str(), image);

            std::cout << "Image saved as: " << filename << std::endl;
        } else {
            std::cerr << "Image capture failed!" << std::endl;
        }

        camera.Close(); // Close camera
    } catch (const Pylon::GenericException &e) {
        std::cerr << "Error: " << e.GetDescription() << std::endl;
    }

    Pylon::PylonTerminate(); // Terminate Pylon SDK
    return 0;
}

