#include <pylon/PylonIncludes.h>
#include <GenApi/GenApi.h>
#include <iostream>

void ListNodeMapFeatures(GenApi::INodeMap& nodeMap) {
    GenApi::NodeList_t nodes;
    nodeMap.GetNodes(nodes);

}

int main() {
    // Initialize Pylon SDK
    Pylon::PylonInitialize();

    try {
        // Get all connected cameras
        Pylon::DeviceInfoList devices;
        Pylon::CTlFactory::GetInstance().EnumerateDevices(devices);

        if (devices.empty()) {
            std::cerr << "No cameras found!" << std::endl;
            return 1;
        }

        // Iterate through each camera
        for (const auto& deviceInfo : devices) {
            // Open camera
            Pylon::CInstantCamera camera(Pylon::CTlFactory::GetInstance().CreateDevice(deviceInfo));
            camera.Open();
            std::cout << "Camera ID: " << deviceInfo.GetSerialNumber() << std::endl;

            // Get the node map from the camera
            GenApi::INodeMap& nodeMap = camera.GetNodeMap();

            // List all features in the node map
            ListNodeMapFeatures(nodeMap);

            // Take a "snapshot" of the camera's current timestamp value
            GenApi::CCommandPtr timestampLatchCommand(nodeMap.GetNode("GevTimestampControlLatch"));
            if (timestampLatchCommand && GenApi::IsAvailable(timestampLatchCommand) && GenApi::IsWritable(timestampLatchCommand)) {
                timestampLatchCommand->Execute();  // Execute the command to latch the timestamp
            } else {
                std::cerr << "TimestampLatch command is not available or writable for Camera ID " << deviceInfo.GetSerialNumber() << std::endl;
                continue;  // Skip this camera
            }

            // Get the timestamp value
            GenApi::CIntegerPtr timestampValueParam(nodeMap.GetNode("GevTimestampValue"));
            if (timestampValueParam && GenApi::IsReadable(timestampValueParam)) {
                int64_t timestampValue = timestampValueParam->GetValue();
                std::cout << "Timestamp for Camera ID " << deviceInfo.GetSerialNumber() << ": " << timestampValue << std::endl;
            } else {
                std::cerr << "TimestampLatchValue is not readable for Camera ID " << deviceInfo.GetSerialNumber() << std::endl;
            }

            // Close the camera
            camera.Close();
        }
    } catch (const Pylon::GenericException& e) {
        std::cerr << "Error: " << e.GetDescription() << std::endl;
    }

    // Terminate Pylon SDK
    Pylon::PylonTerminate();

    return 0;
}
