#include <pylon/PylonIncludes.h>
#include <GenApi/GenApi.h>  // Required for GenApi features
#include <iostream>

int main() {
    // Initialize the Pylon SDK
    Pylon::PylonInitialize();

    try {
        // Connect to the first available camera
        Pylon::CInstantCamera camera(Pylon::CTlFactory::GetInstance().CreateFirstDevice());
        camera.Open(); // Open the camera

        // Access the camera parameters
        GenApi::INodeMap& nodeMap = camera.GetNodeMap(); // Removed Pylon::GenApi

        // Set Exposure Time (Example: 20000 µs)
        GenApi::CFloatPtr exposureTime = nodeMap.GetNode("ExposureTimeAbs"); // Removed Pylon::GenApi
        if (GenApi::IsWritable(exposureTime)) { // Removed Pylon::GenApi
            exposureTime->SetValue(20000.0);
            std::cout << "Exposure Time set to: " << exposureTime->GetValue() << " µs" << std::endl;
        } else {
            std::cerr << "Failed to write ExposureTime parameter!" << std::endl;
        }

        // Get the current Exposure Time
        if (GenApi::IsReadable(exposureTime)) { // Removed Pylon::GenApi
            double currentExposure = exposureTime->GetValue();
            std::cout << "Current Exposure Time: " << currentExposure << " µs" << std::endl;
        } else {
            std::cerr << "Failed to read ExposureTime parameter!" << std::endl;
        }

        camera.Close(); // Close the camera
    } catch (const Pylon::GenericException &e) {
        std::cerr << "Error: " << e.GetDescription() << std::endl;
    }

    // Terminate the Pylon SDK
    Pylon::PylonTerminate();
    return 0;
}

