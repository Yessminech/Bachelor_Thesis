var structCameraConfig =
[
    [ "exposure", "structCameraConfig.html#ae65ad57a93121f31ac49169a6f3119da", null ],
    [ "gain", "structCameraConfig.html#af3ed8ea4bdad592452d1f1e9f118d3c4", null ],
    [ "height", "structCameraConfig.html#a510ecf9d3020f0d2c1c392c81d3ef4a1", null ],
    [ "pixelFormat", "structCameraConfig.html#acc14ac4623795ae0651c352df6d97ea5", null ],
    [ "width", "structCameraConfig.html#aedc5c1be2aca3a5647fc7aa7be8af59a", null ]
];