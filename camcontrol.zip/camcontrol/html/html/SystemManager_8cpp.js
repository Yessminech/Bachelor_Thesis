var SystemManager_8cpp =
[
    [ "handleSignal", "SystemManager_8cpp.html#aa025f45ed88b3ae4067ae664cf12f853", null ],
    [ "stopStream", "SystemManager_8cpp.html#ae5ae244cb5c554668ccfdb36eb04700c", null ]
];