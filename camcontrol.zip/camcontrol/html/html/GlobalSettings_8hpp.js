var GlobalSettings_8hpp =
[
    [ "CYAN", "GlobalSettings_8hpp.html#ad243f93c16bc4c1d3e0a13b84421d760", null ],
    [ "GREEN", "GlobalSettings_8hpp.html#acfbc006ea433ad708fdee3e82996e721", null ],
    [ "RED", "GlobalSettings_8hpp.html#a8d23feea868a983c8c2b661e1e16972f", null ],
    [ "RESET", "GlobalSettings_8hpp.html#ab702106cf3b3e96750b6845ded4e0299", null ],
    [ "YELLOW", "GlobalSettings_8hpp.html#abf681265909adf3d3e8116c93c0ba179", null ],
    [ "getGlobalFpsLowerBound", "GlobalSettings_8hpp.html#acfe3de5aca0ac60294465da621db079c", null ],
    [ "getGlobalFpsUpperBound", "GlobalSettings_8hpp.html#ae20198dd587799aa9d5579c3597f7fb4", null ],
    [ "getSessionTimestamp", "GlobalSettings_8hpp.html#a292086bff16224cc0653061c22440e60", null ],
    [ "setGlobalFpsLowerBound", "GlobalSettings_8hpp.html#aab7020ba8042dd684e45e015e778f91a", null ],
    [ "setGlobalFpsUpperBound", "GlobalSettings_8hpp.html#a4e4d4e3815c368773a4dfcfc9d19666c", null ],
    [ "bufferPercent", "GlobalSettings_8hpp.html#a5636c3771e20017849393e595a8d5723", null ],
    [ "debug", "GlobalSettings_8hpp.html#a398527b3e9e358c345c5047b16871957", null ],
    [ "defaultCti", "GlobalSettings_8hpp.html#a5e986ec3f9182feba00515217cd928e9", null ],
    [ "g_fpsLowerBound", "GlobalSettings_8hpp.html#aee4a4acebf76ded37032bc3f49c62fc3", null ],
    [ "g_fpsUpperBound", "GlobalSettings_8hpp.html#aa8514985df46f2271b46b119e3f14c3b", null ],
    [ "minExposureTimeMicros", "GlobalSettings_8hpp.html#ace8c90260b4f4211b6001712af4a5dad", null ],
    [ "monitorPtpStatusTimeoutMs", "GlobalSettings_8hpp.html#a412b58577459f3071900f59a56778d1c", null ],
    [ "packetSizeB", "GlobalSettings_8hpp.html#a3b8ee519de2c22ee9a9229943161b597", null ],
    [ "ptpMaxCheck", "GlobalSettings_8hpp.html#aa4202e0668937c93c8c568b3a43175e3", null ],
    [ "ptpOffsetThresholdNs", "GlobalSettings_8hpp.html#af8a890078f8d5888a0cace2f6ea59f57", null ]
];