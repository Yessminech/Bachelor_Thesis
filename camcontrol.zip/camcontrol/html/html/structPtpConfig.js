var structPtpConfig =
[
    [ "enabled", "structPtpConfig.html#a51d6b51102c948c37167789c7129412f", null ],
    [ "offsetFromMaster", "structPtpConfig.html#ac90eae9c4f55c53b7cd390b7362cf6ba", null ],
    [ "status", "structPtpConfig.html#a9a9cf4bf710d3d6877b9eb1d9fb21c8f", null ],
    [ "tickFrequency", "structPtpConfig.html#ae13f2202714112a5d494c45983d78359", null ],
    [ "timestamp_ns", "structPtpConfig.html#aef5b135da26603fe8378cfae8c3a61a6", null ],
    [ "timestamp_s", "structPtpConfig.html#a3061d612cc702384d4f0ee8132044e8e", null ]
];