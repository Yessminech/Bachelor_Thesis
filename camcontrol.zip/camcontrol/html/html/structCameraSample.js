var structCameraSample =
[
    [ "offset_ns", "structCameraSample.html#a3d1d5379d3a1072a505907c39f553827", null ],
    [ "timestamp_ns", "structCameraSample.html#a5b583207b4eb85244a2dca5863a9b105", null ]
];