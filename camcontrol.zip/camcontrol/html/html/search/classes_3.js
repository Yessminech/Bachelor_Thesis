var searchData=
[
  ['ptpconfig_270',['PtpConfig',['../structPtpConfig.html',1,'']]]
];
