var searchData=
[
  ['globalsettings_2ecpp_350',['GlobalSettings.cpp',['../GlobalSettings_8cpp.html',1,'']]],
  ['globalsettings_2ehpp_351',['GlobalSettings.hpp',['../GlobalSettings_8hpp.html',1,'']]]
];
