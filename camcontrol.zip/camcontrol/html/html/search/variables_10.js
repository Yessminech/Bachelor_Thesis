var searchData=
[
  ['vendor_521',['vendor',['../structDeviceInfos.html#ac4d20a90f0a8ced178664ff1275c160f',1,'DeviceInfos']]],
  ['version_522',['version',['../structDeviceInfos.html#abc621b2fb73752e95468df08990ad798',1,'DeviceInfos']]]
];
