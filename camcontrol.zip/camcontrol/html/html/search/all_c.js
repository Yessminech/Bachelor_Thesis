var searchData=
[
  ['offset_5fns_113',['offset_ns',['../structCameraSample.html#a3d1d5379d3a1072a505907c39f553827',1,'CameraSample']]],
  ['offsetfrommaster_114',['offsetFromMaster',['../structPtpConfig.html#ac90eae9c4f55c53b7cd390b7362cf6ba',1,'PtpConfig']]],
  ['opencameraslist_115',['openCamerasList',['../classDeviceManager.html#a8c32824afb65d41a43370038456e87b5',1,'DeviceManager']]]
];
