var searchData=
[
  ['serialnumber_508',['serialNumber',['../structDeviceInfos.html#a9583f99661b21c6a7e71288b5c84f3da',1,'DeviceInfos']]],
  ['startedthreads_509',['startedThreads',['../classStreamManager.html#a3976886897a8a8223fd611c75c9e0401',1,'StreamManager']]],
  ['status_510',['status',['../structPtpConfig.html#a9a9cf4bf710d3d6877b9eb1d9fb21c8f',1,'PtpConfig']]],
  ['stopstream_511',['stopStream',['../classSystemManager.html#a7d94357eba7a35647dde9390c9175549',1,'SystemManager::stopStream()'],['../SystemManager_8cpp.html#ae5ae244cb5c554668ccfdb36eb04700c',1,'stopStream():&#160;SystemManager.cpp']]],
  ['streammanager_512',['streamManager',['../classSystemManager.html#a58c42a07f1884380e16d9d7b39b2a613',1,'SystemManager']]]
];
