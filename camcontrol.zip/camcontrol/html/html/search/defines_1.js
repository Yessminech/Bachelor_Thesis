var searchData=
[
  ['green_525',['GREEN',['../GlobalSettings_8hpp.html#acfbc006ea433ad708fdee3e82996e721',1,'GlobalSettings.hpp']]]
];
