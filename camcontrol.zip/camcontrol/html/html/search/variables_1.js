var searchData=
[
  ['bufferpercent_464',['bufferPercent',['../structNetworkConfig.html#a92f89ece0dd6e2e0b6b11fcfeb02dd40',1,'NetworkConfig::bufferPercent()'],['../GlobalSettings_8cpp.html#a5636c3771e20017849393e595a8d5723',1,'bufferPercent():&#160;GlobalSettings.cpp'],['../GlobalSettings_8hpp.html#a5636c3771e20017849393e595a8d5723',1,'bufferPercent():&#160;GlobalSettings.cpp']]]
];
