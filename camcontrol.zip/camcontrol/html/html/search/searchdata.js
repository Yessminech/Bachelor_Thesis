var indexSectionsWithContent =
{
  0: "abcdefghilmnopqrstuvwy~",
  1: "cdnpqs",
  2: "cdgnqs",
  3: "acdeghilmnpsu~",
  4: "abcdefghilmnopstvw",
  5: "cgry"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Macros"
};

