var searchData=
[
  ['yellow_257',['YELLOW',['../GlobalSettings_8hpp.html#abf681265909adf3d3e8116c93c0ba179',1,'GlobalSettings.hpp']]]
];
