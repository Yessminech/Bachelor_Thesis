var searchData=
[
  ['red_204',['RED',['../GlobalSettings_8hpp.html#a8d23feea868a983c8c2b661e1e16972f',1,'GlobalSettings.hpp']]],
  ['reset_205',['RESET',['../GlobalSettings_8hpp.html#ab702106cf3b3e96750b6845ded4e0299',1,'GlobalSettings.hpp']]]
];
