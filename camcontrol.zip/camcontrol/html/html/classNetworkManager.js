var classNetworkManager =
[
    [ "NetworkManager", "classNetworkManager.html#a5aaf71c4aa7a2efab7f1dbae02312280", null ],
    [ "~NetworkManager", "classNetworkManager.html#a2cfe4223139cf58587a9f066b956cb23", null ],
    [ "calculateMaxFps", "classNetworkManager.html#acd8737d274da2f02b0e1635b4b9f63bb", null ],
    [ "configureBandwidth", "classNetworkManager.html#a22ca4e3eadd1f887bb5f90f98570709f", null ],
    [ "configurePtpSyncFreeRun", "classNetworkManager.html#a5131787ff8e8985e848e8456c1e6b202", null ],
    [ "disablePtp", "classNetworkManager.html#a72d16c3ed9d65f8f9ac365fd576d9077", null ],
    [ "enablePtp", "classNetworkManager.html#a97139087ce2feb24bce02b5e26ef1cf5", null ],
    [ "getMinimumExposure", "classNetworkManager.html#a2894fa4186d5341d1ceea4930cd1f448", null ],
    [ "logOffsetHistoryToCSV", "classNetworkManager.html#ae856b2f8ac57cb540414667eccc6832a", null ],
    [ "monitorPtpOffset", "classNetworkManager.html#a580689530037e60c278f61c2d541e86c", null ],
    [ "monitorPtpStatus", "classNetworkManager.html#a5cff683bdb24c9f3359fc259e73cc036", null ],
    [ "plotOffsets", "classNetworkManager.html#ae34ac9fc3697d706c4938c61f44ecd59", null ],
    [ "printPtpConfig", "classNetworkManager.html#a8f23d31231702bcd91a3cf101a8394e6", null ],
    [ "setExposureAndFps", "classNetworkManager.html#a88d3b203ca5c2d28212c5da9f8cdde7d", null ],
    [ "setOffsetfromMaster", "classNetworkManager.html#a04994b3d5241bef4167923c6bd0fedd5", null ],
    [ "masterClockId", "classNetworkManager.html#a6b81e052e5a1b29f42ac8caa8659277d", null ],
    [ "timeWindowSize", "classNetworkManager.html#aa87ffa8389cb80f21e1717e80d8fc7e6", null ]
];