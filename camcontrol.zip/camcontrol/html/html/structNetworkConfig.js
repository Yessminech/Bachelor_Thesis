var structNetworkConfig =
[
    [ "bufferPercent", "structNetworkConfig.html#a92f89ece0dd6e2e0b6b11fcfeb02dd40", null ],
    [ "deviceLinkSpeedBps", "structNetworkConfig.html#a2dd6cb9580c73b2700be4ad312ad45d9", null ],
    [ "fps", "structNetworkConfig.html#af48368071e6af065cf20853898c56bb4", null ],
    [ "packetDelayNs", "structNetworkConfig.html#ae3a985ee311d5f7219051d17af5cb7b1", null ],
    [ "packetSizeB", "structNetworkConfig.html#a816bd68959354b2c8e9608a5d147b42c", null ],
    [ "transmissionDelayNs", "structNetworkConfig.html#adad0e00a0f3017ed1e081f85ed52afd2", null ]
];