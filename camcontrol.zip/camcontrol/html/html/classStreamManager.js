var classStreamManager =
[
    [ "StreamManager", "classStreamManager.html#a91044033de4432d2f689ca3709a18716", null ],
    [ "~StreamManager", "classStreamManager.html#a2ca7bc50460e72eefc1215bb6e44a3b8", null ],
    [ "createComposite", "classStreamManager.html#a9f70fad5bf4dd5108911c05af8f649e3", null ],
    [ "startFreeRunStream", "classStreamManager.html#a0257fcf9f99184dee55ffe95ab5a9c4c", null ],
    [ "startPtpSyncFreeRun", "classStreamManager.html#a87567b0edf6975bd31e8176b7fe5cbce", null ],
    [ "stopStreaming", "classStreamManager.html#abfb94b1e01cc9952b575a78995532e30", null ],
    [ "globalFrameMutex", "classStreamManager.html#afb513189e756e920471dc37918b5cd32", null ],
    [ "globalFrames", "classStreamManager.html#ac961215e22087ad691551b548ea5a83e", null ],
    [ "startedThreads", "classStreamManager.html#a3976886897a8a8223fd611c75c9e0401", null ],
    [ "threads", "classStreamManager.html#aa22195847716575e354b539dfb237e40", null ]
];