var cli_8cpp =
[
    [ "main", "cli_8cpp.html#a0ddf1224851353fc92bfbff6f499fa97", null ],
    [ "parseCameraIDs", "cli_8cpp.html#ae87714a32069a99bdee647bb2c4a6c65", null ],
    [ "printUsage", "cli_8cpp.html#a99cfd7f582dfad8278b8ebaddcaa9e41", null ]
];