var structDeviceInfos =
[
    [ "accessStatus", "structDeviceInfos.html#a053725fab665d5157f8f53e535e48b77", null ],
    [ "currentIP", "structDeviceInfos.html#a68e44eefae5c375d65897b5ece3a0aff", null ],
    [ "deprecatedFW", "structDeviceInfos.html#a2d4b33847f98026607dc449001c2cee1", null ],
    [ "displayName", "structDeviceInfos.html#a22f72df0e2d1db3bc47dc902bada8762", null ],
    [ "id", "structDeviceInfos.html#a7db7c1f0734aaeaf22934598eee31082", null ],
    [ "MAC", "structDeviceInfos.html#a96a7817890baf94800d584111bdb45e7", null ],
    [ "model", "structDeviceInfos.html#a104ccbdf7bc5fbd96cf717aeb9dcd01f", null ],
    [ "serialNumber", "structDeviceInfos.html#a9583f99661b21c6a7e71288b5c84f3da", null ],
    [ "timestampFrequency", "structDeviceInfos.html#a9d4529d19fe53ebfd93e9b5b28b5c2ee", null ],
    [ "tlType", "structDeviceInfos.html#afcfabe1997627aba0f586357b57d3cee", null ],
    [ "vendor", "structDeviceInfos.html#ac4d20a90f0a8ced178664ff1275c160f", null ],
    [ "version", "structDeviceInfos.html#abc621b2fb73752e95468df08990ad798", null ]
];