var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "Camera.cpp", "Camera_8cpp.html", null ],
    [ "Camera.hpp", "Camera_8hpp.html", [
      [ "DeviceInfos", "structDeviceInfos.html", "structDeviceInfos" ],
      [ "PtpConfig", "structPtpConfig.html", "structPtpConfig" ],
      [ "NetworkConfig", "structNetworkConfig.html", "structNetworkConfig" ],
      [ "CameraConfig", "structCameraConfig.html", "structCameraConfig" ],
      [ "Camera", "classCamera.html", "classCamera" ]
    ] ],
    [ "cli.cpp", "cli_8cpp.html", "cli_8cpp" ],
    [ "DeviceManager.cpp", "DeviceManager_8cpp.html", null ],
    [ "DeviceManager.hpp", "DeviceManager_8hpp.html", [
      [ "DeviceManager", "classDeviceManager.html", "classDeviceManager" ]
    ] ],
    [ "GlobalSettings.cpp", "GlobalSettings_8cpp.html", "GlobalSettings_8cpp" ],
    [ "GlobalSettings.hpp", "GlobalSettings_8hpp.html", "GlobalSettings_8hpp" ],
    [ "NetworkManager.cpp", "NetworkManager_8cpp.html", "NetworkManager_8cpp" ],
    [ "NetworkManager.hpp", "NetworkManager_8hpp.html", [
      [ "CameraSample", "structCameraSample.html", "structCameraSample" ],
      [ "NetworkManager", "classNetworkManager.html", "classNetworkManager" ]
    ] ],
    [ "qcustomplot.cpp", "qcustomplot_8cpp.html", null ],
    [ "StreamManager.cpp", "StreamManager_8cpp.html", null ],
    [ "StreamManager.hpp", "StreamManager_8hpp.html", [
      [ "StreamManager", "classStreamManager.html", "classStreamManager" ]
    ] ],
    [ "SystemManager.cpp", "SystemManager_8cpp.html", "SystemManager_8cpp" ],
    [ "SystemManager.hpp", "SystemManager_8hpp.html", [
      [ "SystemManager", "classSystemManager.html", "classSystemManager" ]
    ] ]
];